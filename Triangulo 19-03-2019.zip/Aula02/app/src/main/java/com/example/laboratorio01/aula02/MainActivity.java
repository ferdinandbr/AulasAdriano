package com.example.laboratorio01.aula02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    Button botaoAcao;
    EditText txt1;
    EditText txt2;
    EditText txt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botaoAcao = findViewById(R.id.botaoAcao);
        txt1= findViewById(R.id.txtLado1);
        txt2= findViewById(R.id.txtLado2);
        txt3= findViewById(R.id.txtLado3);

        int v1= Integer.parseInt(txt1.getText().toString());
        int v2= Integer.parseInt(txt2.getText().toString());
        int v3= Integer.parseInt(txt3.getText().toString());

        if (v1 == v2 && v1 == v3)
        {
            botaoAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Equilatero",Toast.LENGTH_LONG).show();
                }
            });

        }else if(v1 == v2 || v1 == v3){
            botaoAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Isoceles",Toast.LENGTH_LONG).show();
                }
            });
        }else if (( v1 < v2 + v3 ) && ( v2 < v1 + v3 ) && ( v3 < v1 + v2 )){

            botaoAcao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),"Escaleno",Toast.LENGTH_LONG).show();
                }
            });
        }else{

            botaoAcao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Não é triangulo",Toast.LENGTH_LONG).show();
            }
        });}
    };



}
